import requests
import threading

url = r'http://localhost:33333/page2.html'

def func():
	r = requests.get(url)
	print(r)

for i in range(100):
	t = threading.Thread(target=func)
	t.start()
