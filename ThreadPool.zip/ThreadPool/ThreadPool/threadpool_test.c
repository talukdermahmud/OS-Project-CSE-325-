/**
 * threadpool_test.c, copyright 2001 Steve Gribble
 * Just a regression test for the threadpool code.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include "threadpool.h"
#include "threadpool.c"

void log()
{
	char st[] = "thissiisjdfisdifsidjfoasdfjasdfjosd jsdfjlksdjflkasjdflkajsdl;kfja;lskdjfa;klsdjfl;kasdjfkl;asdjfklasjdf;lkajsd;klfj	asdfjalsdjflkasdjfl;kasdjflkasjdflkajsd;lfkjasd;lkfjla;skdjf;klasdjfklasdjflk;asdjflk;dsjfkldsjf;lkasjdf;lkasjdfkl\n";
	int fd = open("test.log", O_CREAT| O_WRONLY | O_APPEND,0644);
	write(fd, st, strlen(st));
	close(fd);
}

void dispatch_to_me(void *arg) {
	log();
  int seconds = (int) arg;
  fprintf(stdout, "  in dispatch %d\n", seconds);
  fprintf(stdout, "  done dispatch %d\n", seconds);
}
int main(int argc, char **argv) {
  threadpool tp;
  int i = 0;

  tp = create_threadpool(1);
  for(;i < 5;i ++) {
	  dispatch(tp, dispatch_to_me, (void *) i);
  }
  fprintf(stdout, "**main** done first\n");
  sleep(1);
  fprintf(stdout, "\n\n");
  for(i = 0;i < 20;i ++) {
	  dispatch(tp, dispatch_to_me, (void *) i);
  }
  fprintf(stdout, "**main done second\n");
  sleep(1);
  destroy_threadpool(tp);
  exit(-1);
}
