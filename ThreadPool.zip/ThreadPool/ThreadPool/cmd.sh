killall -9 a.out
gcc threadserverfinal.c -lpthread
